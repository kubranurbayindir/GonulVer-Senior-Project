<!DOCTYPE html>
<html lang="tr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">

    <title>Etkinliklerimiz</title>
   
    <!-- Favicons -->
    <link href="assets/images/favicon.png" rel="icon">


    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="vendor/glightbox/css/glightbox.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center justify-content-lg-between">

      <h1 class="logo me-auto me-lg-0" style="margin-right:auto !important"><a href="../#hero">Gönül Ver</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
            <li><a class="nav-link scrollto active" href="../#hero">Ana Sayfa</a></li>
            <li><a class="nav-link scrollto" href="../#about">Hakkımızda</a></li>
            <li><a class="nav-link scrollto" href="../#services">Faaliyetlerimiz</a></li>
            <li><a class="nav-link scrollto " href="../#portfolio">Etkinliklerimiz</a></li>
            <li><a class="nav-link scrollto" href="../#contact">İletişim</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle" ></i>
      </nav><!-- .navbar -->
        
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Etkinlik Detayları</h2>
          <ol>
            <li><a href="../#hero">Ana Sayfa</a></li>
            <li>Etkinlik Detayları</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text">
      <div class="container-fluid">
        <div class="owl-banner owl-carousel">
          <div class="item">
            <img src="assets/images/aybu1.jpg" alt="">
            <div class="item-content">
              
              <div class="main-content">
                <div class="meta-category">
                
                </div>

              </div>
            
            </div>
          </div>
          <div class="item">
            <img src="assets/images/bur2.jpg" alt="">
            <div class="item-content">
              
              <div class="main-content">
                <div class="meta-category">
               
                </div>

              </div>
            
            </div>
          </div>
          <div class="item">
            <img src="assets/images/health.jpg" alt="">
            <div class="item-content">
              
              <div class="main-content">
                <div class="meta-category">
                 
                </div>
              </div>
            
            </div>
          </div>
          <div class="item">
            <img src="assets/images/aybu2.jpg" alt="">
            <div class="item-content">
              
              <div class="main-content">
                <div class="meta-category">
              
                </div>

              </div>
            
            </div>
          </div>
          <div class="item">
            <img src="assets/images/aybu3.jpg" alt="">
            <div class="item-content">
              
              <div class="main-content">
                <div class="meta-category">
               
                </div>

               

                
              </div>
            
            </div>
          </div>
          <div class="item">
            <img src="assets/images/burs 3.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                
                </div>

              
              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/burs1.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
               
                </div>

             

              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/health1.jpg" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                 
                </div>

                

              </div>
            </div>
          </div>
          <div class="item">
            <img src="assets/images/health2.png" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                
                </div>

              

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <section class="blog-posts grid-system">
      <div class="container">
        <div class="all-blog-posts">
          <h2 class="text-center">Etkinliklerimiz</h2>
          <br>
          <div class="row">
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/aybu1.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="ghandi-agac-dikimi.php"><h4> Ghandi Ağaç Dikimi</h4></a>
                  <p>Mahatma Gandhi'nin doğumunun 150. yılı dolayısıyla Yıldırım Beyazıt Üniversitesi Esenboğa Kampüsünde 150 adet boylu fidan dikilecek.</p>

                  <ul class="post-info">
                    <li><a href="#">Ankara Orman Bölge Müdürlüğü</a></li>
                    <li><a href="#">04.04.2019 10.00</a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/aybu2.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="agac-dikme-senligi.php"><h4>Ağaç Dikme Şenliği</h4></a>
                  
                  <p>Ankara Yıldırım Beyazıt Üniversitesi, Esenboğa Külliye'sinde ağaç dikme şenliği etkinliği düzenlenecektir.<br>
                    Dileyen herkesi etkinliğimize bekliyoruz.</p>

                  <ul class="post-info">
                    <li><a href="#">Ankara Yıldırım Beyazıt Üniversitesi</a></li>
                    <li><a href="#">07.12.2021 10:00</a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/aybu3.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="agac-dikme-etkinligi.php"><h4>Ağaç Dikme Etkinliği</h4></a>
                  
                  <p>Ankara Yıldırım Beyazıt Üniversitesi Esenboğa Külliyemizde senin de bir ağacın olsun.<br>
                    Ağaç dikme etkinliğine herkes davetlidir.</p>

                  <ul class="post-info">
                    <li><a href="#">Ankara Yıldırım Beyazıt Üniversitesi</a></li>
                    <li><a href="#">29.03.2022 10:00</a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
              
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/burs1.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="baskentin-günesleri-etkinligi.php"><h4>Başkentin Güneşleri Projesi</h4></a>
                  
                  <p>Ailesinin maddi olanakları kısıtlı olup, ikametgâhı Ankara’da olan veya Ankara’da
                     örgün eğitim gören öğrencilere burs yardımı yapılacaktır.</p>

                  <ul class="post-info">
                    <li><a href="#">Ankara Büyükşehir Belediyesi</a></li>
                    <li><a href="#">10.07.2021 </a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/bur2.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="sutas-egitime-destek-bursu.php"><h4>Sütaş Eğitime Destek Bursu</h4></a>
                  
                  <p>Sütaş Eğitime Destek Bursları, üniversitelerde lisans düzeyde öğrenim gören başarılı ve maddi imkânları yetersiz öğrencilere karşılıksız burs verilmektedir.</p>

                  <ul class="post-info">
                    <li><a href="#">Sütaş</a></li>
                    <li><a href="#">01-21 Eylül,2022 </a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/burs 3.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="birbirimize-destek-zamani.php"><h4>Birbirimize Destek Zamanı</h4></a>
                  
                  <p>Yemeksepeti uygulaması üzerinden ilk etapta UNICEF'in “Koronavirüsü Acil Durum Fonu”, TEV’in “Yemek Yardımı Fonu”na bağış yaparak destek olabilecekler.</p>

                  <ul class="post-info">
                    <li><a href="#">UNICEF</a></li>
                    <li><a href="#">10.06.2021</a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
              
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/health2.png" alt="">
                </div>
                <div class="down-content">
                  <a href="engelsiz-yasam.php"><h4>Saray Engelsiz Yaşam Ve Rehabilitasyon Merkezi Gezisi</h4></a>
                  
                  <p>Saray Engelsiz Yaşam Bakım ve Rehabilitasyon Merkezine, Ankara Yıldıırm Beyazıt üniveristesi Öğrencileri olarak gezi düzenlenecektir.<br>
                  İlgili kişilerin katılımlarını bekliyoruz.(Kontenjan sınırlıdır.)</p>

                  <ul class="post-info">
                    <li><a href="#">Saray Rehabilitasyon Merkezi</a></li>
                    <li><a href="#">20.03.2022 14:00-15:00</a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/health.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="covid-19-psikososyal-destek-hizmeti.php"><h4>COVID-19 Psikososyal Destek Hizmeti</h4></a>
                  
                  <p>Bireyin ve ailenin tıbbi müdahalesi yanı sıra ruhsal ve sosyal iyilik halinin korunması amacıyla Ankara İl Sağlık Müdürlüğü ve bağlı kuruluşlarımızda sosyal çalışmacı, psikolog ve çocuk gelişimciler tarafından "Psiko-Sosyal Destek Birimleri" kurulmuştur.</p>

                  <ul class="post-info">
                    <li><a href="#">T.C Sağlık Bakanlığı</a></li>
                    <li><a href="#">Hafta içi 09:00/16:00</a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6">
              <div class="blog-post">
                <div class="blog-thumb">
                  <img src="assets/images/health1.jpg" alt="">
                </div>
                <div class="down-content">
                  <a href="alzheimer-ve-demans-bulusma-merkezi.php"><h4>Alzheimer ve Demans  Buluşma Merkezi Projesi</h4></a>
                  
                  <p>Alzheimer ve Demans hastası olduğuna dair teşhis konulmuş olan,
                    Kendi ihtiyaçlarını karşılamasını engelleyici bir rahatsızlığı bulunmayan,
                    Günlük yaşam ihtiyaçlarını bağımsız olarak yapabilecek durumda olan,
                    Mersin/Mezitli-Yenişehir ilçeleri sınırları içerisinde ikamet ediyor olan herkes başvurabilir.</p>

                  <ul class="post-info">
                    <li><a href="#">Mersin Büyükşehir Belediyesi</a></li>
                    <li><a href="#">10.06.2020 </a></li>
                    <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                  </ul>
                </div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </section>

 

     <!-- ======= Footer ======= -->
 <footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">

        <div class="col-lg-3 col-md-6">
          <div class="footer-info">
            <h3>Gönül Ver</h3>
            <p>
              Dumlupınar Mahallesi <br>
              Esenboğa/Ankara<br><br>
              <strong>Telefon:</strong> +90 312 906 1000<br>
              <strong>Mail:</strong> aybugonulver@gmail.com<br>
            </p>
               <div class="social-links mt-3">
                 <a href="https://twitter.com/aybugv" class="twitter"><i class="bx bxl-twitter"></i></a>
                 <a href="https://www.instagram.com/aybugv/?hl=tr" class="instagram"><i class="bx bxl-instagram"></i></a>
               </div>
          </div>
        </div>

        <div class="col-lg-2 col-md-6 footer-links">
          <h4>Hızlı Erişim</h4>
            
        <ul>
            <li><i class="bx bx-chevron-right"></i><a class="nav-link scrollto active" href="../#hero">Ana Sayfa</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#about">Hakkımızda</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#services">Faaliyetlerimiz</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#portfolio">Etkinliklerimiz</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#contact">İletişim</a></li>
        </ul>
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
        </div>

        <div class="col-lg-4 col-md-6 footer-newsletter">
          <h4>Abone Ol</h4>
          <p>Abone Ol Bizden Haberdar Ol!</p>
          <form action="" method="post">
            <input type="email" name="email"><input type="submit" value="Abone Ol">
          </form>

        </div>

      </div>
    </div>
  </div>

  <div class="container">
    <div class="copyright">
      &copy; Copyright <strong><span>Gönül Ver</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="#about" >Gönül Ver</a>
    </div>
  </div>
</footer><!-- End Footer -->

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>
      
    <script src="assets/js/main.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>