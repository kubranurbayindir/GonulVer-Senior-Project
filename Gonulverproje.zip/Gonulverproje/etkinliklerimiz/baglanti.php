<?php

$vt_sunucu="fdb27.biz.nf";
$vt_kullanici="3803817_gonulver";
$vt_sifre="gonulver06";
$vt_adi="3803817_gonulver";

$baglan=mysqli_connect($vt_sunucu, $vt_kullanici, $vt_sifre, $vt_adi);

if(!$baglan)
{    

    die("veri tabanı bağlantı işlemi başarısız".mysqli_connect_error());

}else{
    echo "Gönülver";
}

?>