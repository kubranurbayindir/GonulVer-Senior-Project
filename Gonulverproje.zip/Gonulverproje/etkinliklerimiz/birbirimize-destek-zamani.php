<!DOCTYPE html>
<html lang="tr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">

    <title>Etkinlik Detay</title>
    <link href="assets/images/favicon.png" rel="icon">
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="vendor/glightbox/css/glightbox.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center justify-content-lg-between">

      <h1 class="logo me-auto me-lg-0"  style="margin-right:auto !important"><a href="../#hero">Gönül Ver</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
            <li><a class="nav-link scrollto active" href="../#hero">Ana Sayfa</a></li>
            <li><a class="nav-link scrollto" href="../#about">Hakkımızda</a></li>
            <li><a class="nav-link scrollto" href="../#services">Faaliyetlerimiz</a></li>
            <li><a class="nav-link scrollto " href="../#portfolio">Etkinliklerimiz</a></li>
            <li><a class="nav-link scrollto" href="../#contact">İletişim</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4>Etkinlik Detayı</h4>
                <h2>Birbirimize Destek Zamanı</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->
    <section class="blog-posts grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
                <div class="col-lg-12">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="assets/images/burs 3.jpg" alt="">
                    </div>
                    <div class="down-content">
                      <a href="birbirimize-destek-zamani.php"><h4>Birbirimize Destek Zamanı</h4></a>
                      <ul class="post-info">
                        <li><a href="#">UNICEF</a></li>
                        <li><a href="#">10.06.2021</a></li>
                        <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
                      </ul>
                      <p>Yemeksepeti, dayanışmanın her zamankinden daha fazla önem taşıdığı bugünlerde “Birbirimize Destek Zamanı” sloganıyla Türkiye’nin önde gelen sivil toplum kuruluşlarından TEV, Kızılay ve UNICEF iş birliğiyle milyonlarca kullanıcısına yemek siparişlerini verirken aynı zamanda bağış yapabilmelerine ve bu kurumlar aracılığıyla ihtiyacı olan birçok aile ve öğrenciye destek olmalarına gerekli ortamı sağlıyor. <br>
                      Kullanıcılar Yemeksepeti uygulaması üzerinden ilk etapta UNICEF'in “Koronavirüsü Acil Durum Fonu”, Kızılay’ın “Korona Gıda Paketi Desteği Fonu” ve TEV’in “Yemek Yardımı Fonu”na bağış yaparak destek olabilecekler.</p>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-6">
                            
                          </div>
                          <div class="col-6">
                            <ul class="post-share">
                              <li><i class="fa fa-share-alt"></i></li>
                              <li><a href="#">Facebook</a>,</li>
                              <li><a href="#"> Twitter</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-12">
                  
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item submit-comment">
                    <div class="sidebar-heading">
                      <h2>Gönüllü Ol</h2>
                    </div>
                    <div class="content">
                      <form id="comment" action="birbirimize-destek-zamani.php" method="POST">
                        <div class="row">
                          <div class="col-md-6 col-sm-12">
                            <fieldset>
                              <input name="name" type="text" id="name" placeholder="İsim Soyisim" required="">
                            </fieldset>
                          </div>
                          <div class="col-md-6 col-sm-12">
                            <fieldset>
                              <input name="email" type="text" id="email" placeholder="Email Adres" required="">
                            </fieldset>
                          </div>
                          <div class="col-md-12 col-sm-12">
                            <fieldset>
                              <input name="subject" type="text" id="subject" placeholder="Konu">
                            </fieldset>
                          </div>
                          <div class="col-lg-12">
                            <fieldset>
                              <textarea name="message" rows="6" id="message" placeholder="Mesajınızı Yazınız" required=""></textarea>
                            </fieldset>
                          </div>
                          <div class="col-lg-12">
                            <fieldset>
                              <button type="submit" id="form-submit" class="main-button">Gönder</button>
                            </fieldset>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
         
        </div>
      </div>
    </section>

       <!-- ======= Footer ======= -->
    <footer id="footer">
     <div class="footer-top">
       <div class="container">
         <div class="row">
   
           <div class="col-lg-3 col-md-6">
             <div class="footer-info">
               <h3>Gönül Ver</h3>
               <p>
                 Dumlupınar Mahallesi <br>
                 Esenboğa/Ankara<br><br>
                 <strong>Telefon:</strong> +90 312 906 1000<br>
                 <strong>Mail:</strong> aybugonulver@gmail.com<br>
               </p>
               <div class="social-links mt-3">
                 <a href="https://twitter.com/aybugv" class="twitter"><i class="bx bxl-twitter"></i></a>
                 <a href="https://www.instagram.com/aybugv/?hl=tr" class="instagram"><i class="bx bxl-instagram"></i></a>
               </div>
             </div>
           </div>
   
           <div class="col-lg-2 col-md-6 footer-links">
             <h4>Hızlı Erişim</h4>
        <ul>
            <li><i class="bx bx-chevron-right"></i><a href="../#hero">Ana Sayfa</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#about">Hakkımızda</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#services">Faaliyetlerimiz</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#portfolio">Etkinliklerimiz</a></li>
            <li><i class="bx bx-chevron-right"></i><a href="../#contact">İletişim</a></li>
        </ul>
           </div>
   
           <div class="col-lg-3 col-md-6 footer-links">
           </div>
   
           <div class="col-lg-4 col-md-6 footer-newsletter">
             <h4>Abone Ol</h4>
             <p>Abone Ol Bizden Haberdar Ol!</p>
             <form action="" method="post">
               <input type="email" name="email"><input type="submit" value="Abone Ol">
             </form>
   
           </div>
   
         </div>
       </div>
     </div>
   
     <div class="container">
       <div class="copyright">
         &copy; Copyright <strong><span>Gönül Ver</span></strong>. All Rights Reserved
       </div>
       <div class="credits">
         Designed by <a href="#about" >Gönül Ver</a>
       </div>
     </div>
   </footer><!-- End Footer -->


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script src="assets/js/main.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
<?php
    include("baglanti.php");
    

    if(isset($_POST["name"], $_POST["email"], $_POST["subject"], $_POST["message"]))
    {
        $adsoyad=$_POST["name"];
        $email=$_POST["email"];
        $konu=$_POST["subject"];
        $mesaj=$_POST["message"];
        
        
        $ekle="INSERT INTO Iletisim (adsoyad, email, konu, mesaj) VALUES 
        ('".$adsoyad."','".$email."','".$konu."','".$mesaj."')";
   
    if($baglan->query($ekle)===TRUE)
    {
        echo  "<script>alert('Mesajınız Başarı ile Gönderilmiştir.')</script>";
    }
    
    }
?>